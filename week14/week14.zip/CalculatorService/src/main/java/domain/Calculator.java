package domain;

public class Calculator {

    public static int add(int x, int y) {
        return x + y;
    }

    public static int minus(int x, int y) {
        return x - y;
    }

    public static int times(int x, int y) {
        return x * y;
    }
}
